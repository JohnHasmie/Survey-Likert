 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <!-- <?php echo e(__('Edit Responses')); ?>  -->
        <?php echo e($user->name); ?> - <?php echo e($survey->title); ?>

    </h2>
 <?php $__env->endSlot(); ?>
<div class="w-11/12 overflow-scroll mx-auto px-4 sm:px-2 lg:px-2 mt-6">
    <?php if(session()->has('message')): ?>
        <div id="alert" class="text-white px-6 py-4 border-0 rounded relative mt-4 mb-2 bg-green-500">
            <span class="inline-block align-middle mr-8">
                <?php echo e(session('message')); ?>

            </span>
            <button class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-4 mr-6 outline-none focus:outline-none" onclick="document.getElementById('alert').remove();">
                <span>×</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if($sessions && count($sessions)>0): ?>
        <div>
            <div class="inline-block min-w-full shadow rounded-lg overflow-hidden">
                <!-- Table -->
                <table class='mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                    <thead class="bg-gray-50">
                        <tr class="text-gray-600 text-left">
                            <?php if($survey->single_survey): ?>
                                <th class="px-5 py-3 border-b-2 border-black bg-black text-center text-xs font-semibold text-white uppercase tracking-wider">
                                    <!-- Session -->
                                </th>
                            <?php endif; ?>
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="px-5 py-3 border-b-2 border-black bg-black text-center text-xs font-semibold text-white uppercase tracking-wider">
                                    <?php echo e($question->content); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-5 py-3 border-b-2 border-black bg-black text-center text-xs font-semibold text-white uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $__currentLoopData = $session->responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="px-5 py-5">
                                        <?php if($response->link): ?>
                                            <a href="<?php echo e($response->link); ?>" target="_blank" class="text-sm text-gray-700 underline">
                                                <span class="font-semibold px-2 rounded-full">
                                                    <?php echo e($response->content); ?>

                                                </span>
                                            </a>
                                        <?php else: ?>
                                            <span class="font-semibold px-2 rounded-full">
                                                <?php echo e($response->content); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-center">
                                    <button wire:click.prevent="editResponse(<?php echo e($session->id); ?>, <?php echo e($session->responses); ?>)" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                        Edit
                                    </button>
                                    <?php if(!$survey->single_survey): ?>
                                        <button wire:click.prevent="$emit('triggerDelete',<?php echo e($session->id); ?>)" class="mr-2 bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                            Delete
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>

    <?php if($isOpen): ?>
        <div class="fixed z-100 w-full h-full bg-gray-500 opacity-75 top-0 left-0"></div>
            <div class="fixed z-101 w-full h-full top-0 left-0 overflow-y-auto">
                <div class="table w-full h-full py-6">
                    <div class="leading-loose bg-white md:max-w-xl mx-auto rounded">
                        <div class="flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t">
                            <h3 class="text-3xl font-semibold break-all" id="modal-title">
                                <!-- Modal Title -->
                                <?php echo e($survey->title); ?>

                                <p class="px-4 text-lg"><?php echo e($survey->description); ?> </p>
                            </h3>
                            <button class="p-1 ml-auto bg-white border-0 text-black float-right text-3xl leading-none font-semibold outline-none focus:outline-none" wire:click="closeModal">
                                <span class="bg-white text-black h-6 w-6 text-2xl block outline-none focus:outline-none">
                                    ×
                                </span>
                            </button>
                        </div>
                        <form class="max-w-xl m-4 p-4 rounded">
                            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-5">
                                    <label class="font-bold mb-1 block text-sm capitalize text-gray-600" for="cus_email"><?php echo e($question->content); ?></label>
                                    <?php if($question->type === 'text'): ?>
                                        <input class="w-full px-2 py-2 text-gray-700 bg-gray-100 rounded" type="text" wire:model="responses.<?php echo e($question->id); ?>" required="">
                                    <?php endif; ?>
                                    <?php if($question->type === 'textarea'): ?>
                                        <textarea rows="5" class="w-full px-2 py-2 text-gray-700 bg-gray-100 rounded" wire:model="responses.<?php echo e($question->id); ?>"></textarea>
                                    <?php endif; ?>
                                    <?php if($question->type === 'radio'): ?>
                                        <div class="flex flex-col">
                                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="inline-flex items-center mt-1">
                                                    <input value="<?php echo e($option->value); ?>" type="radio" wire:model="responses.<?php echo e($question->id); ?>" name="<?php echo e($question->id); ?>" class="form-checkbox h-5 w-5 text-blue-600">
                                                    <span class="ml-2 text-gray-700"><?php echo e($option->value); ?></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->type === 'checkbox'): ?>
                                        <div class="flex flex-col">
                                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iOption => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="inline-flex items-center mt-1">
                                                    <input value="<?php echo e($option->value); ?>" wire:model="responses.<?php echo e($question->id); ?>.<?php echo e($iOption); ?>" type="checkbox" class="form-checkbox h-5 w-5 text-blue-600">
                                                    <span class="ml-2 text-gray-700"><?php echo e($option->value); ?></span>
                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($question->type === 'date'): ?>
                                        <input type="date" wire:model="responses.<?php echo e($question->id); ?>" class="w-full px-2 py-2 text-gray-700 bg-gray-100 rounded" type="text" required="">
                                    <?php endif; ?>
                                    <?php if($question->type === 'year'): ?>
                                        <select wire:model="responses.<?php echo e($question->id); ?>">
                                            <option value="">Select Year</option>
                                            <?php for($year=date('Y'); $year>=1900; $year--): ?>
                                                <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    <?php endif; ?>
                                    <?php if($question->type === 'number'): ?>
                                        <input type="number" wire:model="responses.<?php echo e($question->id); ?>" class="w-full px-2 py-2 text-gray-700 bg-gray-100 rounded" type="text" required="">
                                    <?php endif; ?>
                                    <?php if($question['type'] === 'file'): ?>
                                       <div
                                            x-data="{ isUploading: false, progress: 0 }"
                                            x-on:livewire-upload-start="isUploading = true"
                                            x-on:livewire-upload-finish="isUploading = false"
                                            x-on:livewire-upload-error="isUploading = false"
                                            x-on:livewire-upload-progress="progress = $event.detail.progress"
                                        >
                                            <input type="file" wire:model="responses.<?php echo e($question['id']); ?>" class="w-full px-2 py-1 text-gray-700 bg-gray-100 rounded border border-gray-500" type="text" required="">
                                            <?php $__errorArgs = ['responses.' . $question['id']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <br>
                                            <?php if(isset($responses[$question['id']])): ?>
                                                <?php if(gettype($responses[$question['id']]) !== 'string' && str_contains($responses[$question['id']]->getMimeType(), 'image')): ?>
                                                    File Preview:
                                                    <img src="<?php echo e($responses[$question['id']]->temporaryUrl()); ?>">
                                                <?php endif; ?>
                                                <?php if(gettype($responses[$question['id']]) === 'string'): ?>
                                                    <!-- File Preview: -->
                                                    <img class="mt-2 underline" src="<?php echo e(asset('storage/files/' . $survey->id . '/' . $question['id'] . '/' . $user->id . '/' . $responses[$question['id']])); ?>" alt="Open in new tab to see file">
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <div x-show="isUploading">
                                                <progress max="100" x-bind:value="progress"></progress>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </form>
                        <div class="px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <span class="flex w-full sm:ml-3 sm:w-auto">
                                <button wire:click.prevent="store()" class="px-4 py-1 font-light tracking-wider bg-blue-500 hover:bg-blue-700 text-white rounded font-bold" type="submit">
                                    Save
                                </button>
                            </span>
                            <span class="mt-3 flex w-full sm:mt-0 sm:w-auto">
                                <button wire:click="closeModal()" class="px-4 py-1 font-light tracking-wider bg-white hover:bg-gray-200 border border-gray-300 text-gray-500 font-bold rounded" type="submit">Cancel</button>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.js"></script>
<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function () {

        window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', sessionId => {
            Swal.fire({
                title: 'Are You Sure?',
                text: 'Response this session record will be deleted!',
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Delete!'
            }).then((result) => {
                if (result.value) {
                    window.livewire.find('<?php echo e($_instance->id); ?>').call('deleteResponse',sessionId)
                } else {
                    console.log("Canceled");
                }
            });
        });
    })
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH /var/www/html/survey-project/resources/views/livewire/edit-responses.blade.php ENDPATH**/ ?>