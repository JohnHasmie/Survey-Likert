 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <?php echo e(__('List User')); ?>

    </h2>
 <?php $__env->endSlot(); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php if(session()->has('message')): ?>
        <div id="alert" class="text-white px-6 py-4 border-0 rounded relative mt-4 mb-2 bg-green-500">
            <span class="inline-block align-middle mr-8">
                <?php echo e(session('message')); ?>

            </span>
            <button class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-4 mr-6 outline-none focus:outline-none" onclick="document.getElementById('alert').remove();">
                <span>×</span>
            </button>
        </div>
    <?php endif; ?>
    <!-- <button wire:click="create()" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-10">Create New Survey</button> -->
    <?php if($users && count($users)>0): ?>
        <div class="py-10">
            <div class="inline-block min-w-full shadow rounded-lg overflow-hidden">
                <table class="min-w-full leading-normal">
                    <thead>
                        <tr>
                            <th
                                class="px-5 py-3 border-b-2 border-black bg-black text-left text-xs font-semibold text-white uppercase tracking-wider">
                                <?php echo e(__('List User')); ?>

                            </th>
                            <th
                                class="px-5 py-3 border-b-2 border-black bg-black text-left text-xs font-semibold text-white uppercase tracking-wider">
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <tr>
                                <td class="px-5 py-5 bg-white text-xxs <?php if(!$loop->last): ?> border-gray-200 border-b <?php endif; ?>">
                                    <?php echo e($user->name); ?>

                                    <span class="text-xs text-grey">(<?php echo e(isset($userAnswers[$user->name]) ? count($userAnswers[$user->name]) : 0); ?> Survey Answered)</span>
                                </td>
                                <td class="px-5 py-5 bg-white text-sm <?php if(!$loop->last): ?> border-gray-200 border-b <?php endif; ?> text-right">
                                    <div class="inline-block whitespace-no-wrap">
                                        <button wire:click="edit(<?php echo e($user->id); ?>)" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Edit</button>
                                        <button wire:click="$emit('triggerDelete',<?php echo e($user->id); ?>)" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Delete</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="px-6 py-6">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.js"></script>

<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/survey-project/resources/views/livewire/user-survey.blade.php ENDPATH**/ ?>