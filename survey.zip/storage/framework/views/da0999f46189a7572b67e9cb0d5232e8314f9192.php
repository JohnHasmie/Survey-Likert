 <?php $__env->slot('header'); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
        <?php echo e(__('List Survey')); ?>

    </h2>
 <?php $__env->endSlot(); ?>
<div class="w-11/12 overflow-scroll mx-auto px-4 sm:px-2 lg:px-2 mt-6">
    <?php if(session()->has('message')): ?>
        <div id="alert" class="text-white px-6 py-4 border-0 rounded relative mt-4 mb-2 bg-green-500">
            <span class="inline-block align-middle mr-8">
                <?php echo e(session('message')); ?>

            </span>
            <button class="absolute bg-transparent text-2xl font-semibold leading-none right-0 top-0 mt-4 mr-6 outline-none focus:outline-none" onclick="document.getElementById('alert').remove();">
                <span>×</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if($users && count($users)>0): ?>
        <div>
            <div class="inline-block min-w-full shadow rounded-lg overflow-hidden">
                <!-- Table -->
                <table class='mx-auto max-w-4xl w-full whitespace-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden'>
                    <thead class="bg-gray-50">
                        <tr class="text-gray-600 text-left">
                            <th class="px-5 py-3 border-b-2 border-black bg-black text-left text-xs font-semibold text-white uppercase tracking-wider">
                                Survey Name
                            </th>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="px-5 py-3 border-b-2 border-black bg-black text-center text-xs font-semibold text-white uppercase tracking-wider">
                                    <?php echo e($user->name); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-5 py-5">
                                    <p class="">
                                        <?php echo e($survey->title); ?>

                                    </p>
                                    <p class="text-gray-500 text-sm font-semibold tracking-wide">
                                    <?php echo e($survey->description); ?>

                                    </p>
                                </td>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $responseExist = in_array($user->id, array_column($survey->responses->toArray(), 'user_id'))
                                    ?>
                                    <td class="px-5 py-5 text-center">
                                        <?php if($responseExist): ?>
                                            <button wire:click="exportExcel(<?php echo e($survey); ?>, <?php echo e($user->id); ?>)" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                                Answered
                                            </button>
                                        <?php else: ?>
                                            <span class="<?php echo e($responseExist ? 'text-green-800 bg-green-200' : 'text-red-800 bg-red-200'); ?> font-semibold px-2 rounded-full">
                                                <?php echo e($responseExist ? 'Answered' : 'Not Yet'); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
<?php /**PATH /var/www/html/survey-project/resources/views/livewire/survey-users.blade.php ENDPATH**/ ?>