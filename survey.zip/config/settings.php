<?php

return [
    'admin_emails' => explode(', ',  env('ADMIN_EMAILS'))
];