<?php return array (
  'edit-responses' => 'App\\Http\\Livewire\\EditResponses',
  'manage-surveys' => 'App\\Http\\Livewire\\ManageSurveys',
  'show-surveys' => 'App\\Http\\Livewire\\ShowSurveys',
  'survey-users' => 'App\\Http\\Livewire\\SurveyUsers',
  'user-list' => 'App\\Http\\Livewire\\UserList',
);